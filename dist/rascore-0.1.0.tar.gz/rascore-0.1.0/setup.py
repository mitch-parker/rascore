# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['rascore']
install_requires = \
['Bio>=1.3.3,<2.0.0',
 'CairoSVG>=2.5.2,<3.0.0',
 'lxml>=4.6.3,<5.0.0',
 'matplotlib>=3.3.4,<4.0.0',
 'matplotlib_venn>=0.11.6,<0.12.0',
 'numpy>=1.20.1,<2.0.0',
 'pandas>=1.2.4,<2.0.0',
 'pyfiglet>=0.8.post1,<0.9',
 'requests>=2.25.1,<3.0.0',
 'scipy>=1.6.2,<2.0.0',
 'seaborn>=0.11.1,<0.12.0',
 'statannot>=0.2.3,<0.3.0',
 'statsmodels>=0.12.2,<0.13.0',
 'streamlit>=1.4.0,<2.0.0',
 'tqdm']

entry_points = \
{'console_scripts': ['APPLICATION-NAME = rascore:main']}

setup_kwargs = {
    'name': 'rascore',
    'version': '0.1.0',
    'description': 'A tool for analyzing the conformations of RAS structures',
    'long_description': None,
    'author': 'mitch-parker',
    'author_email': 'mitch.isaac.parker@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
